<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
header('Content-Type: application/json');

$host = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "hypatia_db";

try {
    $conn = new mysqli($host, $db_user, $db_pass, $db_name);

    if ($conn->connect_error) {
        throw new Exception("Adatbázis kapcsolódási hiba: " . $conn->connect_error);
    }

    $rawData = file_get_contents("php://input");
    $data = json_decode($rawData, true);

    if (!$data) {
        throw new Exception("Üres adat érkezett a szerverre!");
    }

    $user = $conn->real_escape_string($data['user']);
    $pass = $data['pass'];
    $type = $data['type'];

    if ($type === "register") {
        $hash = password_hash($pass, PASSWORD_BCRYPT);
        $sql = "INSERT INTO users (username, password) VALUES ('$user', '$hash')";
        
        if ($conn->query($sql)) {
            echo json_encode(["success" => true]);
        } else {
            throw new Exception("Hiba a mentéskor: " . $conn->error);
        }
    } 
    
    elseif ($type === "login") {
        $result = $conn->query("SELECT * FROM users WHERE username='$user'");
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            if (password_verify($pass, $row['password'])) {
                echo json_encode(["success" => true]);
            } else {
                echo json_encode(["success" => false, "message" => "Hibás jelszó!"]);
            }
        } else {
            echo json_encode(["success" => false, "message" => "Nincs ilyen felhasználó!"]);
        }
    }

} catch (Exception $e) {
    echo json_encode(["success" => false, "message" => $e->getMessage()]);
}
$conn->close();
?>